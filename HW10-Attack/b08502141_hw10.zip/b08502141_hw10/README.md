## How to run my code?
Just run the code in google colab

## Reference
* model list: https://github.com/osmr/imgclsmob/blob/master/pytorch/pytorchcv/model_provider.py